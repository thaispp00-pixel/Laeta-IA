# Laeta IA — Landing Page

Página estática (HTML + CSS). Não precisa de build, servidor ou dependência.

## Estrutura

```
index.html      página completa
styles.css      estilos globais e responsivos
assets/         logo em fundo transparente
CNAME           domínio personalizado (edite ou remova)
```

## Publicar no GitHub Pages

1. Crie um repositório no GitHub (ex: `laetaia-site`).
2. Envie os arquivos desta pasta para a raiz do repositório:

```bash
git init
git add .
git commit -m "Landing page Laeta IA"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/laetaia-site.git
git push -u origin main
```

3. No repositório: **Settings → Pages → Source: Deploy from a branch → Branch: main / (root) → Save**.
4. Em poucos minutos a página fica no ar em `https://SEU-USUARIO.github.io/laetaia-site/`.

## Domínio próprio (laetaia.com.br)

O arquivo `CNAME` já contém `www.laetaia.com.br`. No painel do seu domínio, crie:

- **CNAME** `www` → `SEU-USUARIO.github.io`
- **A** `@` → `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`

Depois, em **Settings → Pages → Custom domain**, informe `www.laetaia.com.br` e ative **Enforce HTTPS**.
Se não for usar domínio próprio, apague o arquivo `CNAME`.

## O que editar

- **Preços e serviços:** blocos `<article>` na seção `#servicos` do `index.html`.
- **WhatsApp:** procure por `5511987188855` (aparece em 5 links).
- **Perguntas frequentes:** seção `#duvidas`.
- **Cores:** paleta da marca — navy `#0D1330`, violeta `#7668E6`, dourado `#C9922E`, papel `#F7F6F2`.
