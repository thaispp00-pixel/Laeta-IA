# Laeta IA — Landing page

Site estático (HTML + CSS). Não precisa de build.

## Arquivos
- `index.html` — a página
- `styles.css` — estilos globais e responsividade
- `assets/` — logo e marca

## Publicar no GitHub Pages
1. Crie um repositório e envie estes arquivos na raiz da branch `main`.
2. No repositório: **Settings › Pages › Source: Deploy from a branch**, branch `main`, pasta `/ (root)`.
3. Em poucos minutos a página fica no ar em `https://<usuario>.github.io/<repo>/`.

## Domínio próprio (laetaia.com.br)
1. Crie um arquivo `CNAME` na raiz com o conteúdo `www.laetaia.com.br`.
2. No seu registrador, aponte `www` como CNAME para `<usuario>.github.io`.
3. Em **Settings › Pages**, marque **Enforce HTTPS**.

## Editar conteúdo
Textos e preços estão direto no `index.html`. O número de WhatsApp aparece como `https://wa.me/5511987188855` — troque em todas as ocorrências se mudar.
